var searchData=
[
  ['grades_0',['grades',['../struct__student.html#aa6495523ad72007cf509e024603b4127',1,'_student']]]
];
